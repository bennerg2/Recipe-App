//
//  RAViewController.h
//  Recipe App
//
//  Created by Benjamin Thomas Gurrola on 9/17/15.
//  Copyright (c) 2015 DevMountain. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RAViewController : UIViewController

@end
